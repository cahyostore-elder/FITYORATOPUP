from pathlib import Path

ROOT = Path.cwd()
BUFFER: dict[str, str] = {}


def replace_once(path: str, old: str, new: str) -> None:
    file = ROOT / path
    if path not in BUFFER:
        if not file.is_file():
            raise FileNotFoundError(f'Missing project file: {path}')
        BUFFER[path] = file.read_text(encoding='utf-8')
    source = BUFFER[path]
    count = source.count(old)
    if count != 1:
        raise RuntimeError(f'{path}: expected one matching block, found {count}; no source files have been written')
    BUFFER[path] = source.replace(old, new, 1)


# 1) Animated background: deterministic positions avoid Math.random() during render.
p = 'src/components/AnimatedBackground.tsx'
replace_once(p, "import { useMemo } from 'react';\n\n", '')
replace_once(p, '''export default function AnimatedBackground() {
  const orbs = useMemo<Orb[]>(() => {
    const count = 7;
    return Array.from({ length: count }, (_, i) => ({
      size: 240 + Math.round(Math.random() * 260),
      top: `${Math.round(Math.random() * 100)}%`,
      left: `${Math.round(Math.random() * 100)}%`,
      color: ORB_COLORS[i % ORB_COLORS.length],
      duration: `${14 + Math.round(Math.random() * 12)}s`,
      delay: `${Math.round(Math.random() * 8)}s`,
      blur: 60 + Math.round(Math.random() * 40),
    }));
  }, []);

  const particles = useMemo(
    () =>
      Array.from({ length: 28 }, () => ({
        top: `${Math.round(Math.random() * 100)}%`,
        left: `${Math.round(Math.random() * 100)}%`,
        size: 1 + Math.random() * 2.5,
        duration: `${8 + Math.random() * 14}s`,
        delay: `${Math.random() * 10}s`,
        opacity: 0.2 + Math.random() * 0.4,
      })),
    []
  );

  return (''', '''function seededUnit(seed: number): number {
  const value = Math.sin(seed * 12.9898 + 78.233) * 43758.5453;
  return value - Math.floor(value);
}

const ORBS: Orb[] = Array.from({ length: 7 }, (_, i) => ({
  size: 240 + Math.round(seededUnit(i * 7 + 1) * 260),
  top: `${Math.round(seededUnit(i * 7 + 2) * 100)}%`,
  left: `${Math.round(seededUnit(i * 7 + 3) * 100)}%`,
  color: ORB_COLORS[i % ORB_COLORS.length],
  duration: `${14 + Math.round(seededUnit(i * 7 + 4) * 12)}s`,
  delay: `${Math.round(seededUnit(i * 7 + 5) * 8)}s`,
  blur: 60 + Math.round(seededUnit(i * 7 + 6) * 40),
}));

const PARTICLES = Array.from({ length: 28 }, (_, i) => ({
  top: `${Math.round(seededUnit(i * 5 + 101) * 100)}%`,
  left: `${Math.round(seededUnit(i * 5 + 102) * 100)}%`,
  size: 1 + seededUnit(i * 5 + 103) * 2.5,
  duration: `${8 + seededUnit(i * 5 + 104) * 14}s`,
  delay: `${seededUnit(i * 5 + 105) * 10}s`,
  opacity: 0.2 + seededUnit(i * 5 + 106) * 0.4,
}));

export default function AnimatedBackground() {
  const orbs = ORBS;
  const particles = PARTICLES;

  return (''')

# 2) BrandLogo: reset fallback state implicitly when the image source changes.
p = 'src/components/BrandLogo.tsx'
replace_once(p, "import { useEffect, useMemo, useState } from 'react';", "import { useMemo, useState } from 'react';")
replace_once(p, '''  const [candidateIndex, setCandidateIndex] = useState(0);

  useEffect(() => {
    setCandidateIndex(0);
  }, [brand.slug, brand.image_url]);

  const currentImage = candidates[candidateIndex];''', '''  const sourceKey = `${brand.slug}:${brand.image_url ?? ''}`;
  const [fallbackState, setFallbackState] = useState({ sourceKey: '', index: 0 });
  const candidateIndex = fallbackState.sourceKey === sourceKey ? fallbackState.index : 0;
  const currentImage = candidates[candidateIndex];''')
replace_once(p, "onError={() => setCandidateIndex((index) => index + 1)}", "onError={() => setFallbackState((current) => ({ sourceKey, index: current.sourceKey === sourceKey ? current.index + 1 : 1 }))}")

# 3) Navbar: route-scoped state closes the menu automatically on navigation.
p = 'src/components/Navbar.tsx'
replace_once(p, "  const [mobileOpen, setMobileOpen] = useState(false);", "  const [mobileOpenPath, setMobileOpenPath] = useState<string | null>(null);\n  const mobileOpen = mobileOpenPath === path;")
replace_once(p, "\n  useEffect(() => setMobileOpen(false), [path]);\n", "\n")
replace_once(p, "if (event.key === 'Escape') setMobileOpen(false);", "if (event.key === 'Escape') setMobileOpenPath(null);")
replace_once(p, "onClick={() => setMobileOpen((v) => !v)}", "onClick={() => setMobileOpenPath((current) => current === path ? null : path)}")

# 4) PromoSlider: initial state already shows loading; retry starts it from the click handler.
p = 'src/components/PromoSlider.tsx'
replace_once(p, "  const loadBanners = useCallback(async () => {\n    setLoading(true);\n    setLoadError('');\n    try {", "  const loadBanners = useCallback(async () => {\n    try {")
replace_once(p, 'onClick={() => void loadBanners()} className="btn-ghost mt-3 rounded-lg px-4 py-2 text-sm">Coba lagi</button>', 'onClick={() => { setLoading(true); setLoadError(\'\'); void loadBanners(); }} className="btn-ghost mt-3 rounded-lg px-4 py-2 text-sm">Coba lagi</button>')

# 5) AdminPage: derive loading from the account whose data has completed loading.
p = 'src/pages/AdminPage.tsx'
replace_once(p, "  const { profile, session, loading: authLoading } = useAuth();", "  const { profile, session, loading: authLoading } = useAuth();\n  const isAuthorized = Boolean(session && profile && (profile.role === 'admin' || profile.role === 'author'));")
replace_once(p, "  const [loading, setLoading] = useState(true);", "  const [loadedFor, setLoadedFor] = useState<string | null>(null);\n  const loading = isAuthorized && loadedFor !== (session?.user?.id ?? null);")
replace_once(p, "    } finally {\n      setLoading(false);\n    }\n  }, []);", "    } finally {\n      setLoadedFor(session?.user?.id ?? null);\n    }\n  }, [session?.user?.id]);")
replace_once(p, '''  useEffect(() => {
    if (authLoading) {
      setLoading(true);
      return;
    }
    if (!session || !profile || (profile.role !== 'admin' && profile.role !== 'author')) {
      setLoading(false);
      return;
    }
    setLoading(true);
    void loadAll();
  }, [authLoading, session, profile, loadAll]);''', '''  useEffect(() => {
    if (authLoading || !isAuthorized) return;
    void loadAll();
  }, [authLoading, isAuthorized, loadAll]);''')

# 6) Dashboard: key order loading to account+retry and keep edits in an explicit local draft.
p = 'src/pages/DashboardPage.tsx'
replace_once(p, "  const [loading, setLoading] = useState(true);", "  const [loadedFor, setLoadedFor] = useState<string | null>(null);")
replace_once(p, '''  const [displayName, setDisplayName] = useState('');
  const [bio, setBio] = useState('');
  const [saving, setSaving] = useState(false);
  const [savedMsg, setSavedMsg] = useState('');
  const [saveError, setSaveError] = useState('');
  const [profileDirty, setProfileDirty] = useState(false);''', '''  const [profileDraft, setProfileDraft] = useState<{ displayName: string; bio: string } | null>(null);
  const [saving, setSaving] = useState(false);
  const [savedMsg, setSavedMsg] = useState('');
  const [saveError, setSaveError] = useState('');
  const displayName = profileDraft?.displayName ?? profile?.display_name ?? '';
  const bio = profileDraft?.bio ?? profile?.bio ?? '';
  const profileDirty = profileDraft !== null;
  const orderLoadKey = session?.user?.id ? `${session.user.id}:${reloadOrders}` : null;
  const loading = Boolean(orderLoadKey && loadedFor !== orderLoadKey);''')
replace_once(p, '''  useEffect(() => {
    if (!session?.user?.id) {
      setLoading(false);
      return;
    }
    let active = true;
    setLoading(true);
    (async () => {''', '''  useEffect(() => {
    if (!session?.user?.id) return;
    const requestKey = `${session.user.id}:${reloadOrders}`;
    let active = true;
    (async () => {''')
replace_once(p, '''      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => { active = false; };
  }, [session?.user?.id, reloadOrders]);

  useEffect(() => {
    // Do not overwrite an in-progress profile edit when auth/profile data refreshes.
    if (profile && !profileDirty) {
      setDisplayName(profile.display_name ?? '');
      setBio(profile.bio ?? '');
    }
  }, [profile, profileDirty]);''', '''      } finally {
        if (active) setLoadedFor(requestKey);
      }
    })();
    return () => { active = false; };
  }, [session?.user?.id, reloadOrders]);''')
replace_once(p, '''      setDisplayName(cleanName);
      setBio(cleanBio);
      await refreshProfile();
      setProfileDirty(false);''', '''      await refreshProfile();
      setProfileDraft(null);''')
replace_once(p, "onClick={() => { setOrdersError(''); setLoading(true); setReloadOrders((value) => value + 1); }}", "onClick={() => { setOrdersError(''); setReloadOrders((value) => value + 1); }}")
replace_once(p, "onChange={(e) => { setDisplayName(e.target.value); setProfileDirty(true); setSavedMsg(''); }}", "onChange={(e) => { setProfileDraft((current) => ({ displayName: e.target.value, bio: current?.bio ?? profile?.bio ?? '' })); setSavedMsg(''); }}")
replace_once(p, "onChange={(e) => { setBio(e.target.value); setProfileDirty(true); setSavedMsg(''); }}", "onChange={(e) => { setProfileDraft((current) => ({ displayName: current?.displayName ?? profile?.display_name ?? '', bio: e.target.value })); setSavedMsg(''); }}")


# 7) TopupPage: remount category-specific flow and derive package state from request identity.
p = 'src/pages/TopupPage.tsx'
replace_once(p, "  const selectBrand = (b: Brand) => {\n    setSelectedBrand(b);", "  const selectBrand = (b: Brand) => {\n    setPackageResult(null);\n    setSelectedBrand(b);")
replace_once(p, '''export default function TopupPage({
  category: categorySlug,
  orderMaintenanceEnabled = false,
  orderMaintenanceMessage = 'Pemesanan sedang dihentikan sementara. Silakan coba kembali nanti.',
}: {
  category: string;
  orderMaintenanceEnabled?: boolean;
  orderMaintenanceMessage?: string;
}) {''', '''type TopupPageProps = {
  category: string;
  orderMaintenanceEnabled?: boolean;
  orderMaintenanceMessage?: string;
};

export default function TopupPage(props: TopupPageProps) {
  return <TopupPageContent key={props.category} {...props} />;
}

function TopupPageContent({
  category: categorySlug,
  orderMaintenanceEnabled = false,
  orderMaintenanceMessage = 'Pemesanan sedang dihentikan sementara. Silakan coba kembali nanti.',
}: TopupPageProps) {''')
replace_once(p, '''  const [packages, setPackages] = useState<Package[]>([]);
  const [loading, setLoading] = useState(true);
  const [catalogError, setCatalogError] = useState('');
  const [catalogAttempt, setCatalogAttempt] = useState(0);
  const [packageLoading, setPackageLoading] = useState(false);
  const [packageError, setPackageError] = useState('');
  const [packageRetry, setPackageRetry] = useState(0);''', '''  const [loading, setLoading] = useState(true);
  const [catalogError, setCatalogError] = useState('');
  const [catalogAttempt, setCatalogAttempt] = useState(0);
  const [packageRetry, setPackageRetry] = useState(0);
  const [packageResult, setPackageResult] = useState<{ requestKey: string; items: Package[]; error: string } | null>(null);''')
replace_once(p, '''  const [error, setError] = useState('');
  const [copied, setCopied] = useState<string | null>(null);

  useEffect(() => {''', '''  const [error, setError] = useState('');
  const [copied, setCopied] = useState<string | null>(null);
  const packageRequestKey = selectedBrand ? `${selectedBrand.id}:${packageRetry}` : '';
  const packages = packageResult?.requestKey === packageRequestKey ? packageResult.items : [];
  const packageError = packageResult?.requestKey === packageRequestKey ? packageResult.error : '';
  const packageLoading = Boolean(selectedBrand && packageResult?.requestKey !== packageRequestKey);

  useEffect(() => {''')
replace_once(p, '''  useEffect(() => {
    let active = true;
    if (!selectedBrand) {
      setPackages([]);
      setPackageError('');
      setPackageLoading(false);
      return () => { active = false; };
    }

    setPackages([]);
    setPackageError('');
    setPackageLoading(true);
    (async () => {
      try {
        const { data, error: packagesError } = await supabase
          .from('packages')
          .select('*')
          .eq('brand_id', selectedBrand.id)
          .order('sort_order')
          .abortSignal(AbortSignal.timeout(12000));
        if (!active) return;
        if (packagesError) {
          setPackages([]);
          setPackageError('Nominal gagal dimuat. Periksa koneksi, lalu coba lagi.');
          return;
        }
        setPackages((data as Package[]) ?? []);
      } catch (error) {
        if (active) {
          const timedOut = error instanceof Error && (error.name === 'TimeoutError' || error.name === 'AbortError');
          setPackageError(timedOut
            ? 'Pemuatan nominal terlalu lama. Periksa internet lalu coba lagi.'
            : 'Koneksi bermasalah saat memuat nominal. Coba lagi.');
        }
      } finally {
        if (active) setPackageLoading(false);
      }
    })();
    return () => { active = false; };
  }, [selectedBrand, packageRetry]);

  useEffect(() => {
    setStep('brand');
    setSelectedBrand(null);
    setSelectedPackage(null);
    setPackageSearch('');
    setPackageSort('recommended');
    setTarget('');
    setServer('');
    setSelectedMethod(null);
    setTargetError('');
    setServerError('');
    setPlacedOrder(null);
    requestIdRef.current = null;
  }, [categorySlug]);''', '''  useEffect(() => {
    if (!selectedBrand) return;
    const requestKey = `${selectedBrand.id}:${packageRetry}`;
    let active = true;
    (async () => {
      try {
        const { data, error: packagesError } = await supabase
          .from('packages')
          .select('*')
          .eq('brand_id', selectedBrand.id)
          .order('sort_order')
          .abortSignal(AbortSignal.timeout(12000));
        if (!active) return;
        if (packagesError) {
          setPackageResult({ requestKey, items: [], error: 'Nominal gagal dimuat. Periksa koneksi, lalu coba lagi.' });
          return;
        }
        setPackageResult({ requestKey, items: (data as Package[]) ?? [], error: '' });
      } catch (error) {
        if (active) {
          const timedOut = error instanceof Error && (error.name === 'TimeoutError' || error.name === 'AbortError');
          setPackageResult({
            requestKey,
            items: [],
            error: timedOut
              ? 'Pemuatan nominal terlalu lama. Periksa internet, lalu coba lagi.'
              : 'Koneksi bermasalah saat memuat nominal. Coba lagi.',
          });
        }
      }
    })();
    return () => { active = false; };
  }, [selectedBrand, packageRetry]);''')

for relative_path, updated_content in BUFFER.items():
    (ROOT / relative_path).write_text(updated_content, encoding='utf-8')

print(f'React Hooks patch berhasil diterapkan ke {len(BUFFER)} file.')
print('Berikutnya jalankan: git diff --check && npm run check')
