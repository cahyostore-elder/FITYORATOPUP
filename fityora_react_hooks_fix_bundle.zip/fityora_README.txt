FITYORATOPUP React Hooks patch

1. Upload this ZIP to /workspaces/FITYORATOPUP/.
2. In the terminal run:
   cd /workspaces/FITYORATOPUP
   mkdir -p /tmp/fityora-react-hooks-fix
   unzip -o fityora_react_hooks_fix_bundle.zip -d /tmp/fityora-react-hooks-fix
   python -m py_compile /tmp/fityora-react-hooks-fix/fityora_react_hooks_fix.py
   python /tmp/fityora-react-hooks-fix/fityora_react_hooks_fix.py
3. If the script completes successfully, run:
   git diff --check
   npm run check

The script modifies source files only after all expected source blocks match.
Do not commit or deploy until checks pass.
