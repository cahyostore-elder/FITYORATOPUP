from pathlib import Path
import re

ROOT = Path.cwd()
CHANGES = {
    "src/components/PromoSlider.tsx": [
        (
            re.compile(r"useEffect\(\(\)\s*=>\s*\{\s*void loadBanners\(\);\s*\},\s*\[loadBanners\]\);"),
            "useEffect(() => {\n    const timer = window.setTimeout(() => { void loadBanners(); }, 0);\n    return () => window.clearTimeout(timer);\n  }, [loadBanners]);",
            "PromoSlider initial-load effect",
        ),
    ],
    "src/pages/AdminPage.tsx": [
        (
            re.compile(r"useEffect\(\(\)\s*=>\s*\{\s*if\s*\(authLoading\s*\|\|\s*!isAuthorized\)\s*return;\s*void loadAll\(\);\s*\},\s*\[authLoading,\s*isAuthorized,\s*loadAll\]\);"),
            "useEffect(() => {\n    if (authLoading || !isAuthorized) return;\n    const timer = window.setTimeout(() => { void loadAll(); }, 0);\n    return () => window.clearTimeout(timer);\n  }, [authLoading, isAuthorized, loadAll]);",
            "AdminPage authorized-load effect",
        ),
    ],
    "src/pages/TopupPage.tsx": [
        (
            re.compile(r"const packages\s*=\s*packageResult\?\.requestKey\s*===\s*packageRequestKey\s*\?\s*packageResult\.items\s*:\s*\[\s*\]\s*;"),
            "const packages = useMemo(\n    () => packageResult?.requestKey === packageRequestKey ? packageResult.items : [],\n    [packageResult, packageRequestKey],\n  );",
            "TopupPage stable packages fallback",
        ),
    ],
}

prepared = {}
errors = []
for relative, replacements in CHANGES.items():
    path = ROOT / relative
    if not path.is_file():
        errors.append(f"File tidak ditemukan: {relative}")
        continue
    original = path.read_text(encoding="utf-8")
    updated = original
    for pattern, replacement, label in replacements:
        matches = list(pattern.finditer(updated))
        if len(matches) != 1:
            errors.append(f"{label}: ditemukan {len(matches)} pola, seharusnya tepat 1")
        else:
            updated = pattern.sub(lambda _m: replacement, updated, count=1)
    if relative.endswith("PromoSlider.tsx") and "setTimeout(() => { void loadBanners(); }, 0)" not in updated:
        errors.append("PromoSlider: validasi callback timer gagal")
    if relative.endswith("AdminPage.tsx") and "setTimeout(() => { void loadAll(); }, 0)" not in updated:
        errors.append("AdminPage: validasi callback timer gagal")
    if relative.endswith("TopupPage.tsx") and "[packageResult, packageRequestKey]" not in updated:
        errors.append("TopupPage: validasi useMemo packages gagal")
    prepared[relative] = (path, original, updated)

if errors:
    print("PATCH DIBATALKAN; tidak ada file yang diubah:")
    for error in errors:
        print(f"- {error}")
    raise SystemExit(1)

for relative, (path, _original, updated) in prepared.items():
    path.write_text(updated, encoding="utf-8")
    print(f"OK: {relative}")

print("Selesai. Tiga koreksi diterapkan; tidak ada file lain yang disentuh.")
