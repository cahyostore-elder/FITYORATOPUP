from pathlib import Path
import re

ROOT = Path.cwd()

promo_path = ROOT / "src/components/PromoSlider.tsx"
admin_path = ROOT / "src/pages/AdminPage.tsx"
topup_path = ROOT / "src/pages/TopupPage.tsx"

promo_old = "  useEffect(() => { void loadBanners(); }, [loadBanners]);"
promo_new = """  useEffect(() => {
    let active = true;
    void Promise.resolve().then(() => {
      if (active) return loadBanners();
      return undefined;
    });
    return () => { active = false; };
  }, [loadBanners]);"""

admin_old = """  useEffect(() => {
    if (authLoading || !isAuthorized) return;
    void loadAll();
  }, [authLoading, isAuthorized, loadAll]);"""
admin_new = """  useEffect(() => {
    if (authLoading || !isAuthorized) return;
    let active = true;
    void Promise.resolve().then(() => {
      if (active) return loadAll();
      return undefined;
    });
    return () => { active = false; };
  }, [authLoading, isAuthorized, loadAll]);"""

# Preflight all exact source shapes before modifying any file.
for path in (promo_path, admin_path, topup_path):
    if not path.is_file():
        raise SystemExit(f"File tidak ditemukan: {path.relative_to(ROOT)}")

promo = promo_path.read_text(encoding="utf-8")
admin = admin_path.read_text(encoding="utf-8")
topup = topup_path.read_text(encoding="utf-8")

if promo.count(promo_old) != 1:
    raise SystemExit("PromoSlider: pola useEffect lama tidak ditemukan tepat satu kali. Tidak ada file yang diubah.")
if admin.count(admin_old) != 1:
    raise SystemExit("AdminPage: pola useEffect lama tidak ditemukan tepat satu kali. Tidak ada file yang diubah.")
if "const EMPTY_PACKAGES: Package[] = [];" in topup:
    raise SystemExit("TopupPage: EMPTY_PACKAGES sudah ada. Tidak ada file yang diubah.")

package_lines = [line for line in topup.splitlines() if re.match(
    r"^\s*const packages = packageResult\?\.requestKey === packageRequestKey \? packageResult\.items : \[\];$", line
)]
if len(package_lines) != 1:
    raise SystemExit("TopupPage: fallback packages tidak cocok dengan pola yang diharapkan. Tidak ada file yang diubah.")
if topup.count("export default function TopupPage(") != 1:
    raise SystemExit("TopupPage: lokasi penyisipan konstanta tidak unik. Tidak ada file yang diubah.")

# Apply the three narrowly scoped changes.
promo = promo.replace(promo_old, promo_new, 1)
admin = admin.replace(admin_old, admin_new, 1)
topup = re.sub(
    r"(^\s*const packages = packageResult\?\.requestKey === packageRequestKey \? packageResult\.items :) \[\];$",
    r"\1 EMPTY_PACKAGES;",
    topup,
    count=1,
    flags=re.MULTILINE,
)
topup = topup.replace(
    "export default function TopupPage(",
    "const EMPTY_PACKAGES: Package[] = [];\n\nexport default function TopupPage(",
    1,
)

promo_path.write_text(promo, encoding="utf-8")
admin_path.write_text(admin, encoding="utf-8")
topup_path.write_text(topup, encoding="utf-8")

print("Patch diterapkan pada 3 file:")
print("- PromoSlider.tsx: pemanggilan fetch dijadwalkan sebagai microtask dan dibatalkan saat effect cleanup.")
print("- AdminPage.tsx: pemanggilan loadAll dijadwalkan sebagai microtask dan dibatalkan saat effect cleanup.")
print("- TopupPage.tsx: fallback packages memakai EMPTY_PACKAGES yang stabil.")
print("Belum menjalankan lint/build; jalankan npm run check untuk verifikasi.")
